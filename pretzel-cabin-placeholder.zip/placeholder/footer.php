<div style="height: 100px"></div>

<div class="container-fluid footer" style="position: fixed; bottom: 0;">

  	<div class="copy"><?php printf(__('&copy; %s PretzelCabin.com', 'pretzel-cabin'), date_i18n('Y')) ?></div>

    <?php wp_footer(); ?>

</div>

</body>
</html>
