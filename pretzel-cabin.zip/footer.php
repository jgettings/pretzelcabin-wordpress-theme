
<div class="container-fluid footer">
		<div class="row">
    	<?php dynamic_sidebar('Footer'); ?>
    </div>

  	<div class="copy"><?php printf(__('&copy; %s PretzelCabin.com', 'pretzel-cabin'), date_i18n('Y')) ?></div>

    <?php wp_footer(); ?>

</div>

</body>
</html>
